package com.example.myhomework1;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private HomeworkAdapter adapter;
    private List<Homework> homeworkList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        homeworkList = new ArrayList<>();
        adapter = new HomeworkAdapter(this, homeworkList);
        listView.setAdapter(adapter);

        new GetHomeworkData().execute("http://192.168.0.125/myhw1/fetch_data.php");
    }

    private class GetHomeworkData extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            StringBuilder result = new StringBuilder();
            try {
                URL url = new URL(params[0]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }
                reader.close();
            } catch (Exception e) {
                Log.e("GetHomeworkData", "Error fetching data", e);;
            }
            return result.toString();
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                JSONArray jsonArray = new JSONArray(result);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);

                    int homeworkID = jsonObject.getInt("HomeworkID");
                    String studentName = jsonObject.getString("StudentName");
                    String subjectName = jsonObject.getString("SubjectName");
                    String homeworkName = jsonObject.getString("HomeworkName");
                    String homeworkDue = jsonObject.getString("HomeworkDue");
                    String homeworkDesc = jsonObject.getString("HomeworkDesc");

                    Homework homework = new Homework(homeworkID, studentName, subjectName, homeworkName, homeworkDue, homeworkDesc);
                    homeworkList.add(homework);
                }
                adapter.notifyDataSetChanged();
            } catch (Exception e) {
                Log.e("GetHomeworkData", "Error parsing JSON data", e);
            }
        }
    }
}