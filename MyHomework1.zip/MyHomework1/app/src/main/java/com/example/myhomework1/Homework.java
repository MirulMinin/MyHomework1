package com.example.myhomework1;

public class Homework {
    private int homeworkID;
    private String studentName;
    private String subjectName;
    private String homeworkName;
    private String homeworkDue;
    private String homeworkDesc;

    public Homework(int homeworkID, String studentName, String subjectName, String homeworkName, String homeworkDue, String homeworkDesc) {
        this.homeworkID = homeworkID;
        this.studentName = studentName;
        this.subjectName = subjectName;
        this.homeworkName = homeworkName;
        this.homeworkDue = homeworkDue;
        this.homeworkDesc = homeworkDesc;
    }

    public int getHomeworkID() {
        return homeworkID;
    }

    public void setHomeworkID(int homeworkID) {
        this.homeworkID = homeworkID;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public String getHomeworkName() {
        return homeworkName;
    }

    public void setHomeworkName(String homeworkName) {
        this.homeworkName = homeworkName;
    }

    public String getHomeworkDue() {
        return homeworkDue;
    }

    public void setHomeworkDue(String homeworkDue) {
        this.homeworkDue = homeworkDue;
    }

    public String getHomeworkDesc() {
        return homeworkDesc;
    }

    public void setHomeworkDesc(String homeworkDesc) {
        this.homeworkDesc = homeworkDesc;
    }
}
