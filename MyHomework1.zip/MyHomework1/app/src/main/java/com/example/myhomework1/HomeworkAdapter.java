package com.example.myhomework1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class HomeworkAdapter extends ArrayAdapter<Homework> {
    private Context context;
    private List<Homework> homeworks;

    public HomeworkAdapter(Context context, List<Homework> homeworks) {
        super(context, 0, homeworks);
        this.context = context;
        this.homeworks = homeworks;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Homework homework = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_homework, parent, false);
        }

        TextView studentName = convertView.findViewById(R.id.subject_name);
        TextView subjectName = convertView.findViewById(R.id.student_name);
        TextView homeworkName = convertView.findViewById(R.id.homework_name);
        TextView homeworkDue = convertView.findViewById(R.id.homework_due);
        TextView homeworkDesc = convertView.findViewById(R.id.homework_desc);

        studentName.setText(homework.getStudentName());
        subjectName.setText(homework.getSubjectName());
        homeworkName.setText(homework.getHomeworkName());
        homeworkDue.setText(homework.getHomeworkDue());
        homeworkDesc.setText(homework.getHomeworkDesc());

        return convertView;
    }
}

